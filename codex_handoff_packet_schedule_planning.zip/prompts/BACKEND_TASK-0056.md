```markdown
You are a Codex coding agent working in this repo.

## TASK-0056 — Template-driven scheduling review loop (Stage05–Stage07)

### Goal
Make `schedule_planning.v1` behave like a real operator workflow:
- require specific EMPTY templates for missing info
- allow agent/code to generate **draft** artifacts (real artifact versions)
- require user review + canonical confirm-review before advancing
- keep officialness strictly via approvals + pointer promotion

### Required inputs (must use exact templates from repo)
Stage05 EMPTY templates:
- fixtures/workflows/schedule_planning/template_pack/Stage05_Draft_Schedule_Triage/Stage05_Draft_Schedule_Triage_Document_Template_EMPTY.docx
- fixtures/workflows/schedule_planning/template_pack/Stage05_Draft_Schedule_Triage/Stage05_Draft_Schedule_Triage_Spreadsheet_Template_EMPTY.xlsx

Stage06 EMPTY templates:
- fixtures/workflows/schedule_planning/template_pack/Stage06_Supervisor_Review_Publish/Stage06_Supervisor_Review_Publish_Document_Template_EMPTY.docx

Stage07 EMPTY templates:
- fixtures/workflows/schedule_planning/template_pack/Stage07_Intraday_Exception_Control/Stage07_Intraday_Exception_Control_Document_Template_EMPTY.docx
- fixtures/workflows/schedule_planning/template_pack/Stage07_Intraday_Exception_Control/Stage07_Intraday_Exception_Control_Spreadsheet_Template_EMPTY.xlsx

### Must implement
1) **Template registry**
   - Add a versioned registry (YAML) for templates (template_id → file path, media_type, stage, dataset_key).
   - Add download endpoints so UI can fetch templates by template_id.

2) **Server-side task requirement model**
   - For each human task compute:
     - required_uploads[] (dataset_key + template_id + artifact_kind + required_count + status)
     - required_reviews[] (draft artifacts to review + status)
     - blocking_reason_codes
     - available_actions
   - Use this in workspace/task projections so UI is thin.

3) **Canonical confirm-review**
   - POST /api/v1/human-tasks/{human_task_id}/confirm-review
   - Creates evidence artifact `human_task.review_confirmation.json`
   - Links it to the human_task and the reviewed artifact_version_ids
   - Idempotent

4) **Agent draft artifacts**
   - Agent/code may create draft:
     - `schedule.stage06.publish_packet` (draft artifact)
     - draft `schedule.published_schedule.workbook`
     - `schedule.stage07.replan_packet` (draft artifact)
     - draft `schedule.replan_delta.workbook`
   - Agent/code must NOT promote official pointers directly.

5) **Stage06 task kind reconciliation**
   - Align Stage06 task kinds with WORKFLOW_CONTRACT (prefer `final_review` and `information_request`)
   - Remove/resolve any mismatch like `review_packet` unless the contract is updated consistently.

6) **Scenario runner + export bundle**
   - Provide demo scenarios and a zip export of key run artifacts:
     - requirements state
     - review confirmations
     - draft artifacts and official pointers
     - timeline excerpt

### Required tests/scenarios
A) Stage05 missing workbook → information_request requires Stage05 spreadsheet template upload; completion blocked until uploaded
B) Stage06 publish-ready → generate draft publish packet + draft published schedule workbook → final_review requires confirm-review → approval → pointer promotion
C) Stage07 major replan → require exception_board doc upload → generate draft replan packet + draft delta workbook → final_review requires confirm-review → approval gate if major → pointer promotion

### Verification
Run and record:
- make schema-validate
- make contract
- make replay
- make acceptance
- make runtime
- make runtime-api
- pytest -q

END.
```
