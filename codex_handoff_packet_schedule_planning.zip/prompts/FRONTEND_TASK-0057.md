```markdown
You are a Codex coding agent working in this repo.

## TASK-0057 — Workspace UI: template requests + upload + confirm-review

### Goal
On the single-page workspace (graph on top, swimlanes below):
- show required templates for information_request tasks
- allow template download and response upload inline
- show agent-generated draft artifacts requiring review
- allow canonical confirm-review inline
- keep Complete disabled until server says requirements are met

### Must implement
1) Extend workspace contract types to include:
   - required_uploads[]
   - required_reviews[]
   - blocking_reason_codes
   - available_actions
2) Add repository calls:
   - list/download templates
   - confirm-review mutation
3) Update task cards/rows:
   - show “Download Template” for required_uploads
   - bind upload to requirement and refresh workspace on success
   - show “Open Draft” + “Confirm Reviewed” for required_reviews
   - disable Complete until unblocked

### Tests
- required upload shows template download
- upload changes UI state after refetch
- required review shows confirm-review
- confirm-review unblocks completion after refetch
- layout remains graph+swimlanes on same page; no extra headings

### Verify
- npm typecheck/test/build
- Manual path: seed scenario → open workspace → download template → upload response → open draft → confirm reviewed → complete → graph advances

END.
```
