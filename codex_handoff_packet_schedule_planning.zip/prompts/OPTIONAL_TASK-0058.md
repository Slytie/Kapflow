```markdown
(Optional) TASK-0058 — Scheduling runbooks/templates packaged like payroll

Goal:
Create scheduling runbook + policy/tool matrix templates in the same style as the provided payroll packs, but clearly marked as derived outputs.

Deliverables:
- fixtures/workflows/schedule_planning/runbooks/...
- template registry for scheduling EMPTY templates + completed examples
- validate_repo.py checks that derived runbook assets exist
- README clarifying canonical (docs/workflows) vs derived (fixtures/workflows)

END.
```
