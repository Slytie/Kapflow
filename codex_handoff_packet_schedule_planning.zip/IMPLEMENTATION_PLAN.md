# Codex Handoff — Template-driven Scheduling Loop (Stage05–Stage07)

This packet contains:
- the **canonical schedule_planning.v1 workflow pack** (contract + artifact map + decision catalog + execution profile + operating model + acceptance)
- the **exact template pack** (EMPTY + COMPLETED examples)
- research that motivates deterministic vs bounded-LLM split and tool/policy best practices
- prompts for backend + frontend implementation

## Canonical workflow pack (source of truth)
Path in this packet:
- `repo_subset/docs/workflows/schedule_planning/v1/*`

Key files:
- `WORKFLOW_CONTRACT.yaml`
- `ARTIFACT_MAP.yaml`
- `DECISION_CATALOG.yaml`
- `EXECUTION_PROFILE.yaml`
- `OPERATING_MODEL.md`
- `ACCEPTANCE_CRITERIA.md`

## Exact templates that MUST be required (EMPTY)
Path in this packet:
- `repo_subset/fixtures/workflows/schedule_planning/template_pack/**`

### Stage05
- `Stage05_Draft_Schedule_Triage/Stage05_Draft_Schedule_Triage_Document_Template_EMPTY.docx`
- `Stage05_Draft_Schedule_Triage/Stage05_Draft_Schedule_Triage_Spreadsheet_Template_EMPTY.xlsx`

### Stage06
- `Stage06_Supervisor_Review_Publish/Stage06_Supervisor_Review_Publish_Document_Template_EMPTY.docx`

### Stage07
- `Stage07_Intraday_Exception_Control/Stage07_Intraday_Exception_Control_Document_Template_EMPTY.docx`
- `Stage07_Intraday_Exception_Control/Stage07_Intraday_Exception_Control_Spreadsheet_Template_EMPTY.xlsx`

## Artifact keys (from ARTIFACT_MAP.yaml)
Minimum for this milestone:

Stage05 inputs:
- `schedule.draft_schedule.doc`
- `schedule.draft_schedule.workbook`

Stage06 inputs/outputs:
- `schedule.supervisor_review.doc` (user upload)
- `schedule.published_schedule.workbook` (agent/code draft first; official after review+approval+promotion)

Stage07 inputs/outputs:
- `schedule.exception_board.doc` (user upload)
- `schedule.replan_delta.workbook` (agent/code draft first; official after review+approval+promotion)

Review packet drafts (projection artifacts):
- `schedule.stage06.publish_packet`
- `schedule.stage07.replan_packet`

## Required behavioral laws
1) **Agent-generated documents are canonical drafts, not official outputs**
   - agent/code can create a real artifact version
   - officialness only via review-confirmation + approvals + pointer promotion

2) **Branching lives in code, not in prompts**
   - LLM may recommend a bounded outcome
   - code emits explicit commands (create task / request approval / create artifact / promote pointer)

3) **Server-computed requirements drive UI**
   - tasks expose `required_uploads[]`, `required_reviews[]`, `available_actions[]`, and blocking reasons

4) **Review confirmation is canonical evidence**
   - `POST /human-tasks/{id}/confirm-review` creates evidence artifact `human_task.review_confirmation.json`

## End-to-end debug scenarios (must be runnable)
A) Stage05 missing workbook → information_request requires Stage05 spreadsheet template upload
B) Stage06 publish-ready → draft publish packet + draft published schedule workbook → final_review requires confirm-review → approval → official pointer promotion
C) Stage07 major replan → require exception_board upload → draft replan packet + draft delta workbook → final_review requires confirm-review → approval (if major) → delta pointer promotion

## Manual evaluation bundle
Add an export script that produces a zip including:
- workspace projection
- tasks/approvals/flags
- requirements state
- review confirmations
- draft artifacts + official pointers
- timeline excerpt
