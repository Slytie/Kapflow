# Realism Assessment of the Stage05–Stage07 Task-Work Breakdown for a Same-Day Logistics Operator

## Executive summary

The proposed split—**deterministic code** for metrics/flags/deltas/threshold checks/pointer promotion, with a **bounded LLM only for short schema-constrained summaries**—is **realistic and operationally well-matched** to how same-day delivery operators (~200 employees) typically run dispatch: publish an official baseline, then manage a high volume of messy intraday deviations via exception control, idempotent updates, and audit trails. The approach is also strongly aligned with the repo’s contract and acceptance criteria: Stage06 “officialness” is defined by **immutable artifact versions + pointer promotions**, and Stage07 requires **deltas that supersede without mutating** the base schedule, with canonical approvals preserved even in an agent-only debug tenant. fileciteturn0file6 fileciteturn0file0 fileciteturn1file0  

Operational fit is strongest where:
- **Latency matters** (Stage07): research on same-day delivery emphasizes that operational dispatch decisions must be **fast (minutes)**, and sometimes **(milli)seconds** when decisions interact directly with customers—favoring deterministic, bounded-search code rather than open-ended reasoning. citeturn2view0  
- **Uncertainty evolves** (Stage07): the dynamic routing literature frames intraday operations as information that arrives and improves over time (dynamic requests, travel-time uncertainty, disruptions), which is best handled with deterministic control loops and explicit state transitions. citeturn0search12turn3search14  
- **Governance is real** (Stage06/07): labor constraints and safety/health requirements impose hard caps on working time and rest (EU and Germany), which in practice drives formal approval gates for overtime-heavy or cross-zone replans, not free-form “AI decisions.” citeturn3search0turn3search1  

Where realism will depend on refinement:
- **Incident taxonomy breadth**: the repo’s minimum taxonomy (e.g., `no_show`, `delay_cluster`, `vehicle_issue`, `address_issue`, `weather_disruption`) is a credible core, but real operators often need additional codes for *hub/sortation delays*, *device/app failures*, *access restrictions*, *customer cancellation*, and *inventory/mispick* events. fileciteturn0file0 citeturn1search4turn2view0  
- **Approval thresholds**: the repo currently encodes concrete defaults (5% assignment changes, 10% uncovered zone-hours, +1 average overtime hour) and explicit “major replan triggers.” These are plausible starting points, but whether they generate a manageable approval load depends on how “assignment changes” are defined (shift/zone reassignment vs stop resequencing). fileciteturn0file3 fileciteturn0file4  
- **Blast radius modeling**: real-time routing often changes *stop order* frequently without changing *who owns a shift/zone*; if the repo treats every route reorder as an “assignment change,” approvals will be spammy. If “assignment change” is strictly worker↔zone/shift reassignment, the defaults are more realistic. citeturn2view0turn3search23  

Bottom line: the deterministic/LLM split is realistic for ~200 employees, and it is a good design for auditability and end-to-end testing—provided you (a) keep authoritative state transitions fully code-driven, (b) strengthen the incident taxonomy and “information missing” pathways, and (c) calibrate thresholds to keep **major approvals rare but meaningful**. fileciteturn0file0 fileciteturn0file6 fileciteturn1file0  

## Evidence on operational fit for a 200-employee same-day operator

### Staffing and roles mapping

The repo’s role set (`schedule_planner`, `dispatch_supervisor`, `operations_manager`, `fleet_coordinator`) is consistent with how same-day delivery organizations separate responsibilities: planning and pre-publish review are handled by planners/supervisors, while cost/policy exceptions and major intraday replans are escalated to a more senior operations decision-maker. fileciteturn0file4 fileciteturn0file6  

This aligns with academic accounts of same-day delivery ecosystems that include multiple stakeholders (customers, depots/retailers, third-party delivery entities, and courier fleets), and explicitly highlight the operational challenge that **orders, picking/packing, and routing happen within the same day under uncertainty**. citeturn2view0turn3search27  

Practical consequence for the “code vs LLM” split: role boundaries map cleanly onto deterministic, testable “control points” (publish gate; major replan gate) and justify keeping the LLM non-authoritative.

### Frequency and scale of incidents in practice

Even a “small” operator is exposed to **daily stochastic disruptions** across workforce, vehicles, customers, and traffic. Empirical public data rarely publishes neat “no_show vs vehicle_issue” breakdowns for last-mile fleets, but several primary sources support the order-of-magnitude reality:

- **Workforce unavailability is routine**: the U.S. Bureau of Labor Statistics reports an absence rate for “Transportation and warehousing” around **3.1%** (full-time wage and salary workers; absences for illness/injury/other reasons). For any hub scheduling 30–60 couriers per day, that implies a high probability of at least one absence event on a given day, even before considering gig/contractor volatility. citeturn0search2  
- **Traffic delay risk is structurally high in dense cities**: mobility data for the German capital shows substantial congestion (TomTom reports a 2025 average congestion level around the mid‑40% range and identifies high-variation days). This supports the realism of a `delay_cluster` class and argues for “monitor-only” risks carrying into Stage07 even when the base schedule publishes. citeturn5search0  
- **Customer/recipient issues and address/access issues are materially significant** in many attended-home and parcel contexts: research on failed home deliveries reports very wide failure-rate ranges depending on service type and context, and industry reporting often emphasizes “recipient not home” and “incorrect address/access constraints” as major failure contributors. citeturn1search4turn5news41  

Given those realities, the repo’s Stage07 structure—issue-scoped, activation-keyed, delta-based—matches the operational need to handle **frequent small exceptions** while controlling the blast radius of **rare major replans**. fileciteturn0file6 fileciteturn0file0  

### Tooling and latency constraints

Same-day delivery research is explicit that online algorithms must be **fast enough for prompt decision-making**: sometimes within **(milli)seconds** when interacting with customers, and within **minutes** for dispatching decisions during vehicle operations. This strongly supports the repo’s approach of deterministic, bounded-search Stage07 computations and a strict separation between authoritative computations and narrative summaries. citeturn2view0turn3search19  

This also reinforces why the “bounded LLM for summaries” is realistic: LLM calls introduce variable latency and non-determinism; keeping them in non-authoritative, optional summarization pathways preserves operational responsiveness and test stability.

### Approval practices and labor/contract constraints

Real operators require approvals not because “humans like process,” but because:
- Overtime and rest are constrained by law or contracts.
- Contractor activation and SLA waivers have direct cost and customer-commitment impacts.

For a Berlin/Germany operation, the **Working Time Act** (ArbZG) sets a baseline maximum **8 hours/day**, extendable up to **10 hours** under averaging conditions. citeturn3search0turn3search4  
At an EU level, the **Working Time Directive (2003/88/EC)** establishes minimum daily rest and limits on weekly working time. citeturn3search1turn3search9  

The repo’s explicit “major replan triggers” (contractor activation, SLA waiver, zone capacity override, overtime beyond threshold) and decision catalog that requests approvals from an `operations_manager` are therefore realistic governance hooks. fileciteturn0file3 fileciteturn0file2 fileciteturn0file4  

image_group{"layout":"carousel","aspect_ratio":"16:9","query":["last mile delivery dispatch control tower operations center","route optimization dispatch dashboard last mile delivery","same day delivery courier dispatch operations hub"] ,"num_per_query":1}

## Modeled assumptions vs real-world expectations

| Assumption | Repo model | Real-world evidence | Recommended adjustment |
|---|---|---|---|
| Authoritative state is deterministic; LLM only summarizes | Stage05/06/07 are tool-class constrained; official changes via artifact versions + pointer promotions; approvals are canonical even in agent-only debug tenants fileciteturn0file3 fileciteturn0file0 | Same-day dispatch decisions are time-critical (minutes); dynamic uncertainty is pervasive; auditability is essential for post-incident reconstruction citeturn2view0turn0search12turn4search0 | Keep the split. Add strict validation of any LLM output and ensure no path treats LLM text as state. |
| Incident taxonomy can start small (`no_show`, `delay_cluster`, `vehicle_issue`, `address_issue`, `weather_disruption`) | Acceptance criteria requires these as minimum negative cases for publish-vs-replan auditability fileciteturn0file0 | Literature on last-mile failures highlights recipient absence, address/access uncertainty, and broad variability in failure rates. Same-day ops also face hub/sortation delays and dynamic order arrivals citeturn1search4turn2view0turn5news41 | Expand taxonomy with: `sortation_delay`, `item_missing`, `device_offline`, `access_restriction`, `customer_cancel`, `cold_chain_risk`, `safety_block`. Treat these as additive, not breaking. |
| Stage07 should be issue-scoped rather than “rerun whole workflow” | Stage07 semantics: issue-scoped, activation key template, bounded spawn budget, delta supersedes base without mutation fileciteturn0file6 | Dynamic vehicle routing is commonly modeled as event-triggered re-optimization; SDD paper emphasizes uncertainty and multi-period dispatching, but practical control often favors localized adjustments citeturn0search12turn3search23 citeturn3search19 | Keep issue scope, but define “issue merging” rules: multiple incidents can map to one replan packet when correlated (same corridor/time). |
| Major replan thresholds can be defined in % terms | Default thresholds: `changed_assignments_pct=5`, `uncovered_zone_hours_pct=10`, `added_average_overtime_hours=1` plus trigger list fileciteturn0file3 | Percent-only thresholds can misfire at small scale (small hubs) and may overload approvals if “assignment change” is too granular; also constrained by working-time rules citeturn3search0turn3search1 citeturn2view0 | Define “assignment change” at the shift/zone ownership level. Add absolute minima: e.g., `changed_assignments_abs ≥ 4` OR `% ≥ 8–15%` (see thresholds section). |
| Drift after review must be visible | Workflow semantics require drift visibility; acceptance criteria requires a drift-detected event and UI/timeline surfacing fileciteturn0file6 fileciteturn0file0 | In practice, last-minute edits are common near publish cutoff; governance failures are frequent root causes in ops postmortems citeturn4search0 | Keep drift detection strict; add “review snapshot hash” to publish packet; fail publish if drift exceeds policy. |
| Concurrency and retries can be handled via activation keys and leases | Stage07 activation key template and bounded spawn budget; debug tenant supports replayable orchestration fileciteturn0file6 fileciteturn0file0 | Distributed ops require idempotency and safe retries; many event-driven systems adopt explicit idempotency tokens to avoid duplicate side effects citeturn4search0 | Extend idempotency beyond activation: approval requests and publish-version ops should also be idempotent per issue+generation. |

## Recommended numeric thresholds and how to calibrate them

The repo already defines concrete defaults for Stage07 “major replan” gating and an aligned escalation posture in the operating model. fileciteturn0file3 fileciteturn0file4  
Below are recommended **ranges** (not point values) for a ~200-employee operator, designed to (a) keep “major replan” approvals meaningful and (b) bound manager approval load.

### Rationale: keep approvals rare, but not vanishing

A good operational target is that **major replan approvals occur on a minority of service days** for a hub (e.g., p70–p90 days), while “minor deltas” (non-approval) can occur multiple times per day. This matches the reality that absences and traffic variability are common, but not all deviations require a manager-level decision. citeturn0search2turn5search0turn2view0  

### Threshold recommendations

| Control variable | Repo default | Suggested range | Rationale and notes |
|---|---:|---:|---|
| Assignment changes (percent) | 5% fileciteturn0file3 | **8–15%** of *shift/zone ownership assignments* | 5% is often too sensitive for small hubs unless “assignment” is defined coarsely. If “assignment” means worker↔zone/shift reassignment (not stop resequencing), lower values are workable. Use absolute floor too. citeturn2view0 |
| Assignment changes (absolute floor) | (not specified) | **≥ 4–6** assignments changed within next 2–4 hours | Prevents percent spam at small scale. Also corresponds to “blast radius” that operators perceive as disruptive. |
| Uncovered zone-hours (percent) | 10% fileciteturn0file3 | **5–15%** of next-4-hours planned capacity *or* **≥ 1–2 courier-hours** absolute | Traffic uncertainty and late orders can create transient undercoverage; approvals should trigger when the deficit is operationally meaningful rather than noise. citeturn5search0turn0search12 |
| Added average overtime hours | +1 hour fileciteturn0file3 | **0.5–1.5 hours** (average over affected set); **always approve if any courier risks >10h day** | One hour average is a reasonable policy anchor, especially given German daily max 8h (extendable to 10h) and EU rest requirements. citeturn3search0turn3search1 |
| Cross-zone override trigger | Triggered (qualitative) fileciteturn0file4 | **Always major** if it changes zone ownership of any shift in the published schedule | Cross-zone changes create fairness, local-knowledge, and service-quality risks. Treat them separately from “percent changes.” citeturn5search0turn2view0 |
| Contractor activation / SLA waiver | Triggered (qualitative) fileciteturn0file3 | **Always major** | Direct cost and customer-commitment governance. fileciteturn0file4 |

### Calibration method using observable distributions

Because public sources don’t provide a ready-made “dispatch incident distribution,” calibrate thresholds empirically in your own telemetry by collecting (for each hub/day):
- counts of Stage07 incidents by type,
- delta blast radius metrics (assignment change %, absolute changes),
- overtime deltas,
- resulting on-time performance impacts.

This fits the same-day literature’s emphasis on dynamic uncertainty and multi-period decision epochs, and the repo’s audit-first timeline/event inventory approach. citeturn2view0turn3search19 fileciteturn0file0  

## Canonical scenario library for realistic end-to-end testing

Each scenario below is phrased as a **service-day story** with (a) minimal required input artifacts (based on the artifact map) and (b) expected Stage05–Stage07 outputs, including whether a major approval is required. fileciteturn0file1  

### Baseline publish with monitor-only risk

**Inputs**
- Stage03: `schedule.demand_forecast.workbook`
- Stage04: `schedule.capacity_plan.workbook`
- Stage05: `schedule.draft_schedule.workbook` (+ narrative doc as evidence)
- Stage06: supervisor review doc evidence

**Expected outputs**
- Stage05 ops packet flags: `delay_cluster` (monitor-only), no blockers.
- Stage06 decision: approve + publish base schedule.
- Stage07: no deltas (or minor route resequencing that does **not** change shift/zone ownership); no approvals.

**Approval needs**
- None in Stage07.

### Pre-publish courier call-out covered by float

**Inputs**
- Same as baseline, but Stage05 draft includes a float assignment as mitigation.

**Expected outputs**
- Stage05 flags show `undercoverage` resolved by float; residual monitor risks remain.
- Stage06 approve and publish.
- Stage07 minimal (monitor only).

**Approval needs**
- None, unless float reassignment crosses zone boundaries post-publish.

### Intraday no-show forces overtime extension but stays intra-zone

**Inputs**
- Stage06 published base schedule (`schedule.published_schedule.workbook`)
- Stage07 exception board evidence (`schedule.exception_board.doc`)

**Expected outputs**
- Stage07 delta: extend 1–2 shifts (overtime) within same zone; update delta workbook; base unchanged.
- Approval required only if overtime beyond threshold or risks legal caps.

**Approval needs**
- Conditional (depends on overtime delta vs threshold defaults and legal caps). fileciteturn0file3 citeturn3search0  

### Vehicle issue affecting cold-chain capacity

**Inputs**
- Published base schedule includes cold-chain assignment.
- Stage07 exception board indicates `vehicle_issue` and `cold_chain_risk` (recommended taxonomy extension).

**Expected outputs**
- Stage07 delta: reassign qualified reefer-capable courier/vehicle, or activate contractor.
- If contractor activation is required, approval gate triggers.

**Approval needs**
- Major approval if contractor activation or SLA waiver is proposed. fileciteturn0file3 fileciteturn0file2  

### Traffic disruption creates corridor-wide delay cluster

**Inputs**
- Berlin traffic conditions imply elevated risk of clustered delays. citeturn5search0  

**Expected outputs**
- Stage07 deltas remain small where possible (resequencing within assignments).
- If cross-zone rebalancing is required to protect tight time windows, it becomes a major replan.

**Approval needs**
- Major if cross-zone override or zone capacity override occurs. fileciteturn0file4  

### Address/access restriction cluster

**Inputs**
- Stage07 exception board shows multiple `address_issue` incidents.

**Expected outputs**
- Stage07 issues generate follow-on `information_request` tasks if receiver contact/access info is missing (bounded spawn policies).
- Minor deltas: postpone/rollback certain stops, or reattempt windows.

**Approval needs**
- Usually none, unless SLA waiver or major reallocation occurs. fileciteturn0file6  

### Drift after Stage06 review but before promotion

**Inputs**
- Draft schedule updated after supervisor created review snapshot.

**Expected outputs**
- Stage06 emits drift-detected event; publish either blocked or requires re-review depending on policy.
- Timeline captures `promoted_artifact_version_id` and drift evidence. fileciteturn0file0  

**Approval needs**
- Stage06 may require `request_changes` rather than `approve`.

### Cascading concurrent incidents

**Inputs**
- Stage07 exception board includes multiple incidents: `no_show` + `vehicle_issue` + `delay_cluster`.

**Expected outputs**
- Issue merging or linked issues (depending on implementation) with strict activation-key idempotency.
- Spawn budgets respected (`per_issue_max_children`), and no duplicate deltas under retries. fileciteturn0file6  

**Approval needs**
- Likely major if cumulative blast radius exceeds thresholds.

### Mermaid timeline for SD-2026-03-04 canonical story

```mermaid
sequenceDiagram
  autonumber
  participant W as WorkflowRun SD-2026-03-04
  participant S5 as Stage05 Triage (code)
  participant S6 as Stage06 Publish Gate
  participant A6 as Approval: Publish Base
  participant PUB as Published Base Schedule
  participant S7 as Stage07 Live Ops
  participant A7 as Approval: Major Replan
  participant DEL as Replan Delta

  W->>S5: Read Stage03/04/05 workbooks
  S5->>S5: Compute metrics + flags (deterministic)
  S5->>S6: Emit ops_packet projection
  S6->>A6: approval.requested (dispatch_supervisor)
  A6-->>S6: approval.responded = approve
  S6->>PUB: artifact.version.created
  S6->>PUB: artifact.pointer.promoted (base official)

  Note over S7: Live day diverges from plan
  S7->>S7: Parse exception_board (INC-001 no_show; INC-002 delay_cluster)
  S7->>DEL: Create delta rows (extend shift; cross-zone override)
  S7->>A7: approval.requested (operations_manager)
  A7-->>S7: approval.responded = approve
  S7->>DEL: artifact.version.created
  S7->>DEL: artifact.pointer.promoted (delta official)
```

fileciteturn0file6 fileciteturn0file0  

### Mermaid timeline for a major-replan scenario

```mermaid
sequenceDiagram
  autonumber
  participant W as WorkflowRun SD-2026-03-07
  participant PUB as Published Base Schedule
  participant S7 as Stage07 Exception Control
  participant INFO as Info Request Task
  participant A7 as Approval: Major Replan
  participant DEL as Replan Delta

  PUB-->>S7: Base schedule is read-only official state
  S7->>S7: Detect vehicle_issue + cold_chain_risk
  S7->>INFO: Spawn information_request (fleet_coordinator)
  INFO-->>S7: Vehicle availability + ETA confirmed
  S7->>S7: Evaluate candidate actions (bounded search)
  S7->>DEL: Propose delta (contractor_activation + zone override)
  S7->>A7: approval.requested (operations_manager)
  A7-->>S7: approval.responded = approve
  S7->>DEL: Publish delta version + promote pointer
  Note over S7,DEL: Base remains intact; delta supersedes
```

fileciteturn0file6 fileciteturn0file2  

## Concrete agent-only test fixtures and golden assertions

This section translates operational realism into **executable, end-to-end, agent-only tests** that still obey the canonical approval model and audit constraints.

### Fixture structure (minimal, stage-faithful)

Use the artifact map’s keys as test fixture primitives (workbooks/docs), stored under a scenario directory, with deterministic IDs embedded (ScheduleDateID, hub, zones, worker IDs). fileciteturn0file1  

For each scenario, include:
- Stage03 forecast workbook
- Stage04 capacity plan workbook
- Stage05 draft schedule workbook + evidence doc
- Stage06 supervisor review evidence doc
- Stage06 published schedule workbook (expected output fixture)
- Stage07 exception board evidence doc
- Stage07 delta workbook (expected output fixture)

### Golden assertions aligned to acceptance criteria

The following assertions are directly implied by the repo’s acceptance criteria and should be enforced in every end-to-end run:

**Canonical approvals are never bypassed**
- In an agent-only debug tenant, Stage06 and stage07-threshold-triggered approvals must still emit `approval.requested` and `approval.responded`; no tool transcript becomes state. fileciteturn0file0  

**Official state changes occur only through immutable artifacts and pointer promotions**
- Publishing the base schedule produces `artifact.version.created` and `artifact.pointer.promoted`.
- Stage07 produces a delta artifact and promotes its pointer; the published base artifact is unchanged. fileciteturn0file0  

**Publish vs replan remains auditable**
- When an incident occurs after publication (no-show/vehicle issue), the test must assert that the workflow emits a replan delta rather than overwriting the base schedule. fileciteturn0file0  

**Drift after review is visible**
- If a newer draft version exists at promotion time than the one reviewed, emit a drift-detected event and surface it in timeline state. fileciteturn0file0 fileciteturn0file6  

**Idempotency under retries**
- For Stage07 issue tasks, activation key `(workflow_run_id + flag_id + task_kind + generation)` must dedupe retries (no duplicate delta versions for same activation). fileciteturn0file6  

**Spawn budgets are respected**
- Stage07 per-issue spawn budget and max depth are enforced; attempts to exceed create a deterministic escalation outcome. fileciteturn0file6  

### Suggested deterministic metrics to assert (brittleness-resistant)

To avoid brittle “exact schedule equality” assertions (especially if you plug in heuristic solvers later), assert invariant metrics:

- `changed_assignments_pct` equals a known value for the fixture (or is within tolerance if multiple optimal solutions exist).
- `uncovered_zone_hours_pct` decreases after delta (when the delta claims mitigation).
- `added_average_overtime_hours` equals expected and triggers approvals iff threshold crossed (threshold defaults are known). fileciteturn0file3  

This aligns with same-day routing research indicating that online decision-making requires fast, implementable policies rather than exact global optimality, and that stochasticity makes exact-output goldens fragile. citeturn2view0turn3search19  

### Where the bounded LLM is testable without destabilizing the suite

If you include LLM summaries, test them with **schema validation and evidence-reference constraints**, not natural-language equality:
- output must be valid JSON schema (fields present, bounded lengths)
- `top_3_evidence_refs` must reference existing artifact IDs
- `residual_risks_to_monitor` must be a subset of monitor flags emitted by Stage05/Stage07

This preserves the repo’s “no side channel state” requirement and maintains determinism of authoritative state. fileciteturn0file0 fileciteturn1file0