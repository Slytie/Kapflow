# Codex Handoff Packet — Schedule Planning (Template-driven loop)

Open in this order:
1) IMPLEMENTATION_PLAN.md
2) repo_subset/docs/workflows/schedule_planning/v1/* (canonical)
3) repo_subset/fixtures/workflows/schedule_planning/template_pack/* (exact templates + examples)
4) research/* (why this split and how tools should be used)
5) prompts/* (Codex prompts)

This packet is intentionally small: it includes only the workflow pack + templates + research needed for the next implementation slices.
